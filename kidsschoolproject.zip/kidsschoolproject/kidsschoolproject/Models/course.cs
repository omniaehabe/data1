﻿using System.ComponentModel.DataAnnotations.Schema;
namespace kidsschoolproject.Models
{
    public class course
    {
        public int Id { get; set; }
        [ForeignKey("lecture")]
        public int idlecture { get; set; }  
        public string Name { get; set; }
        public double coast { get; set; }
        public List<student_cource> student_Cources { get; set; }
        public List<session> session { get; set; }
        public lecture lecture { get; set; }    
    }
}
