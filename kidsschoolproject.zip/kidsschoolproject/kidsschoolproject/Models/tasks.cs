﻿using System.ComponentModel.DataAnnotations.Schema;
namespace kidsschoolproject.Models
{
    public class tasks
        
    {
        public int Id { get; set; } 
        public string title { get; set; }  
        public string linkform { get; set; }    

        [ForeignKey("student")]
        public int Idstudent { get; set; } 
        [ForeignKey("lecture")]
        public int Idlecture { get; set; }
        public student student { get; set; }
       
        public lecture lecture  { get; set; }
    }
}
