﻿using System.ComponentModel.DataAnnotations.Schema;
namespace kidsschoolproject.Models
{ 
    public class lectuerstudent
    {
        [ForeignKey("lecture")]
        public int idlectuer { get; set; }
        public lecture lecture { get; set; }
        [ForeignKey("student")]
        public int  idstudent { get; set; }

        public student student { get; set; }  
    }
}
