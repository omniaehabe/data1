﻿using System.ComponentModel.DataAnnotations.Schema;
namespace kidsschoolproject.Models
{
    public class student_cource
    {
        [ForeignKey("student")]
        
        public int idstudent { get; set; }

        [ForeignKey("course")]
        public int idcourse { get; set; }   
        public student student { get; set; }
        
        public course course { get; set; }
    }
}
